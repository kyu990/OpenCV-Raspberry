package com.example.Communication.Server.Controller;

import com.example.Communication.Server.DTO.LoginForm;
import com.example.Communication.Server.DTO.Member;
import com.example.Communication.Server.Repository.MemberRepo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@RequiredArgsConstructor
@Controller
public class AccountController {
    final MemberRepo mr;

    @GetMapping("/signin")
    public String signInPage(@SessionAttribute(name = "session", required = false) Member member){
        if(member!=null)
            return "redirect:/";
        return "SignIn";
    }

    @PostMapping("/signin")
    public String signIn(LoginForm login, HttpServletRequest request, RedirectAttributes redirectAttributes){
        Member member = mr.loginMember(login);
        if(member!=null){
            HttpSession session = request.getSession();
            session.setAttribute("session", member);
            return "redirect:/";
        }
        redirectAttributes.addFlashAttribute("error", "아이디 혹은 비밀번호가 일치하지 않습니다.");
        return "redirect:/signin";
    }

    @GetMapping("/signup")
    public String signupPage(){
        return "SignUp";
    }

    @PostMapping("/signup")
    public String register(@RequestParam String id,
                           @RequestParam String pw,
                           @RequestParam String name,
                           @RequestParam String tel,
                           @RequestParam int year,
                           @RequestParam int month,
                           @RequestParam int day){
        Member member = new Member(id,pw,name,tel, LocalDate.of(year, month, day));
        boolean res = mr.registerMember(member);
        if(res)
            return "redirect:/";
        else
            return "redirect:/signup";
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request){
        HttpSession session = request.getSession();
        session.invalidate();
        return "redirect:/";
    }
}
