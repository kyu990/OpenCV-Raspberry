package com.example.Communication.Server.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
@Slf4j
public class EmailService {
    JavaMailSender mailSender;
    final GenerateTokenService gtt;
    @Async
    public void sendMail(String memberId) {

        String resetLink = "http://bearhouseserver.iptime.org:8080/validate?id="+memberId+"&token="+gtt.generateTempToken();

//        String resetLink = "http://bearhouseserver.iptime.org:8080/reset/" + memberId;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(memberId);
        message.setSubject("화재 감지기 인증 방법 안내입니다");
        message.setText("안녕하세요. \n 계정 인증 및 비빌번호 초기화 링크입니다. \n 아래 링크로 이동해 인증 해주세요. \n"
                + resetLink);
        message.setFrom("codingtest99@naver.com");
        message.setReplyTo("codingtest99@naver.com");

        log.info("message: "+message);
        mailSender.send(message);
    }
}

