package com.example.Communication.Server.Repository;

import com.example.Communication.Server.DTO.LoginForm;
import com.example.Communication.Server.DTO.Member;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class MemberRepo {
    private final JdbcTemplate jdbcTemplate;
    public boolean registerMember(Member member){
        int res = jdbcTemplate.update("insert into Member(id, pw, name, tel, birth) values (?,?,?,?,?)",
                member.getId(),
                member.getPw(),
                member.getName(),
                member.getTel(),
                member.getDate()
        );
        return res>0;
    }

    public Member loginMember(LoginForm login){
        List<Member> list = jdbcTemplate.query(
                "select * from Member where id = ? and pw = ?",
                (rs, rowNum) -> {
                    Member member = new Member();
                    member.setId(rs.getString("id"));
                    member.setPw(rs.getString("pw"));
                    member.setName(rs.getString("name"));
                    member.setTel(rs.getString("tel"));
                    return member;
                }, login.getId(), login.getPw()
        );
        return list.isEmpty() ? null : list.get(0);
    }
}
