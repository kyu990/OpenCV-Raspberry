package com.example.Communication.Server.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AboutUsController {
    @GetMapping("/aboutUs")
    public String aboutUsPage1(Model model){
        return "AboutUs";
    }

    @GetMapping("/aboutUs_mem")
    public String aboutUsPage2(Model model){
        return "AboutUs_mem";
    }
}
