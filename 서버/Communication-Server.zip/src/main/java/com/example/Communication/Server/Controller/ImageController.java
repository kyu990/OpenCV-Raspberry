package com.example.Communication.Server.Controller;

import com.example.Communication.Server.Socket.BinarySocketController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.concurrent.ConcurrentLinkedQueue;

@Slf4j
@Controller
public class ImageController {
    @GetMapping("/image")
    public ResponseEntity<Resource> getImage(@RequestParam String sessionId){

        try{
            synchronized(BinarySocketController.imageQueueMap.get(sessionId)){
                if(!BinarySocketController.imageQueueMap.get(sessionId).isEmpty()){
                    byte[] image = BinarySocketController.imageQueueMap.get(sessionId).poll();
                    assert image != null;
                    return ResponseEntity.status(HttpStatus.OK)
                            .contentType(MediaType.IMAGE_JPEG)
                            .body(new ByteArrayResource(image));
                }
                else{
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                }
            }
        }
        catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/reset")
    public ResponseEntity<Void> resetImage(@RequestParam String sessionId){
        try {
            while(true){
                BinarySocketController.imageQueueMap.get(sessionId).poll();
                BinarySocketController.sensorQueueMap.get(sessionId).poll();
                if(BinarySocketController.imageQueueMap.get(sessionId).isEmpty() && BinarySocketController.sensorQueueMap.get(sessionId).isEmpty())
                    break;
                log.info("초기화중");
            }
            return ResponseEntity.ok().build();
        }
        catch (Exception e) {
            log.error("에러 발생: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
