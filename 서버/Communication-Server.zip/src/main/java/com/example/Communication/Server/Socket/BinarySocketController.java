package com.example.Communication.Server.Socket;


import com.example.Communication.Server.DTO.Sensor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.BinaryWebSocketHandler;

import java.io.IOException;
import java.net.URI;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.SynchronousQueue;

@Slf4j
public class BinarySocketController extends BinaryWebSocketHandler {
    public static Map<String, ConcurrentLinkedQueue<byte[]>> imageQueueMap = new HashMap<>();
    public static Map<String, ConcurrentLinkedQueue<Sensor>> sensorQueueMap = new HashMap<>();
    public static Map<WebSocketSession, String> sessionMap = new HashMap<>();
    public static Map<String, WebSocketSession> reverseSessionMap = new HashMap<>();

    //세션 연결 및 ID 저장
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        session.setBinaryMessageSizeLimit(1024*1024*5);
        session.setTextMessageSizeLimit(1024*1024);

        URI uri = session.getUri();
        if (uri != null && uri.getQuery() != null) {
            String query = uri.getQuery();
            String[] queryParams = query.split("&");

            String sessionId = null;
            for (String param : queryParams) {
                String[] keyValuePair = param.split("=");
                if ("sessionId".equals(keyValuePair[0]) && keyValuePair.length > 1) {
                    log.info(sessionId);
                    sessionId = keyValuePair[1];
                    break;
                }
            }

            if (sessionId != null) {
                // 세션 ID를 기반으로 세션을 저장하거나 관리
                sessionMap.put(session, sessionId);
                reverseSessionMap.put(sessionId, session);
                imageQueueMap.put(sessionId, new ConcurrentLinkedQueue<>() {
                });
                sensorQueueMap.put(sessionId, new ConcurrentLinkedQueue<>());
                log.info("Session ID " + sessionId + " is connected.");
                session.sendMessage(new TextMessage("연결 요청 수락"));
            }
            else {
                session.sendMessage(new TextMessage("?sessionId=아이디를 추가해주세요"));
                session.close();
            }
        }
    }

    //세션 연결 해제
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        super.afterConnectionClosed(session, status);
        String sessionId =sessionMap.get(session);

        try{
            imageQueueMap.remove(sessionId);
            sensorQueueMap.remove(sessionId);
            reverseSessionMap.remove(sessionId);
            sessionMap.remove(session);
        }
        catch (Exception e){log.info(e.getMessage());}

        log.info("Session ID : "+sessionId+" 연결 해제");
    }

    //json 형태의 데이터를 객체에 맵핑
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
            String msg = message.getPayload();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule().addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(formatter)));

            try {
                Sensor sensorDTO = mapper.readValue(msg, Sensor.class);
                String sessionId = sessionMap.get(session);
                synchronized (sensorQueueMap.get(sessionId)){
                    sensorQueueMap.get(sessionId).add(sensorDTO);
                }
            } catch (JsonProcessingException e) {
                log.info(e.getMessage());
            }
    }

    @Override
    protected void handleBinaryMessage(WebSocketSession session, BinaryMessage message) throws IOException {

            byte[] payload = Base64.getDecoder().decode(message.getPayload().array());
            String sessionId = sessionMap.get(session);
            synchronized (imageQueueMap.get(sessionId)){
                imageQueueMap.get(sessionId).add(payload);
            }
            log.info("이미지 파일 수신 완료");
    }
}
