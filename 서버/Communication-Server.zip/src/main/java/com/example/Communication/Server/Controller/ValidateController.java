package com.example.Communication.Server.Controller;

import com.example.Communication.Server.Service.EmailService;
import com.example.Communication.Server.Service.GenerateTokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@RequiredArgsConstructor
@Controller
public class ValidateController {
    final GenerateTokenService gtt;
    final EmailService es;
    @GetMapping("/validate/verify")
    public String verifyId(@RequestParam("id")String id, @RequestParam("token")String token){
        boolean res = gtt.validateTempToken(token);
        if(res){
            return "검증 html 넣어야 함";
        }
        else{
            return "링크 만료";
        }
    }

    @GetMapping("/validate")
    public String validateId(RedirectAttributes redirectAttributes){
        redirectAttributes.addFlashAttribute("msg", "인증 메일이 전송되었습니다.");
        es.sendMail("아이디");
        return "초기화 페이지";
    }
}
