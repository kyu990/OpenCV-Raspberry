package com.example.Communication.Server.Repository;

import com.example.Communication.Server.DTO.Sensor;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class SensorRepo {
    private final JdbcTemplate jdbcTemplate;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public List<Sensor> getSensorValue(String id, LocalDateTime time){
        List<Sensor> list = jdbcTemplate.query(
                "select * from Sensor where username = ? and date = ?",
                (rs, rowNum) -> {
                    Sensor sensor = new Sensor();
                    sensor.setTempSensor(rs.getDouble("temp"));
                    sensor.setGasSensor(rs.getInt("gas"));
                    sensor.setLightSensor(rs.getInt("brightness"));
                    sensor.setFireSensor(rs.getBoolean("flame"));
                    sensor.setTime(rs.getTimestamp("date").toLocalDateTime());
                    return sensor;
                }, id, time
        );
        return list;
    }

    public List<Sensor> getSensorValue(String id){
        List<Sensor> list = jdbcTemplate.query(
                "select * from Sensor where username = ? order by date DESC",
                (rs, rowNum) -> {
                    Sensor sensor = new Sensor();
                    sensor.setTempSensor(rs.getDouble("temp"));
                    sensor.setGasSensor(rs.getInt("gas"));
                    sensor.setLightSensor(rs.getInt("brightness"));
                    sensor.setFireSensor(rs.getBoolean("flame"));
                    sensor.setTime(rs.getTimestamp("date").toLocalDateTime());
                    return sensor;
                }, id
        );
        return list;
    }
}
