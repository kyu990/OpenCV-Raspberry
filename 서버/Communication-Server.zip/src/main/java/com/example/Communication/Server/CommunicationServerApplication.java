package com.example.Communication.Server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunicationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunicationServerApplication.class, args);
	}

}
