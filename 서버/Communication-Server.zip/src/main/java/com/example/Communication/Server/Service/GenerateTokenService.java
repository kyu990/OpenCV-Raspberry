package com.example.Communication.Server.Service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@RequiredArgsConstructor
@Service
public class GenerateTokenService {
    private final ConcurrentHashMap<String, Long> tempTokens = new ConcurrentHashMap<>();
    private final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

    public String generateTempToken() {
        String token = UUID.randomUUID().toString();
        long now = System.currentTimeMillis();
        tempTokens.put(token, now);

        // 30분 후에 토큰 만료
        executorService.schedule(() -> tempTokens.remove(token), 30, TimeUnit.MINUTES);

        return token;
    }

    public boolean validateTempToken(String token) {
        Long createTime = tempTokens.get(token);
        if (createTime != null) {
            long now = System.currentTimeMillis();
            if (now - createTime <= 30 * 60 * 1000)
                return true;
            else
                tempTokens.remove(token);
        }
        return false;
    }
}
