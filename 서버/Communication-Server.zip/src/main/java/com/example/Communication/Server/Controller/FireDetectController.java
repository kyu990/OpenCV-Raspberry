package com.example.Communication.Server.Controller;

import com.example.Communication.Server.DTO.Member;
import com.example.Communication.Server.DTO.Sensor;
import com.example.Communication.Server.Socket.BinarySocketController;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class FireDetectController {
    @GetMapping("/fireDetect")
    public String fireDetectPage(Model model, HttpServletRequest request){
        HttpSession session = request.getSession();
        Member member = (Member) session.getAttribute("session"); // 세션에서 Member 객체 가져오기

        if(member != null){
            String username = member.getId(); // Member 객체에서 username 추출
            model.addAttribute("username", username);
            return "FireDetect";
        }

        return "/signin";
    }



    @GetMapping("/updateSensor")
    @ResponseBody
    public Sensor updateSensor(@RequestParam String sessionId){
        synchronized(BinarySocketController.sensorQueueMap.get(sessionId)){
            return BinarySocketController.sensorQueueMap.get(sessionId).poll();
        }
    }
}
