package com.example.Communication.Server.DTO;

import lombok.*;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Sensor {
    double tempSensor;
    int gasSensor;
    int lightSensor;
    boolean fireSensor;
    LocalDateTime time;
}
